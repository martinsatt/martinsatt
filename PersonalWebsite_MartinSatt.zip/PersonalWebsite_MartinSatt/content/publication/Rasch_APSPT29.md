+++
title = "Développement d’une échelle d’évaluation des compétences procédurales dans la formation en physiothérapie: une étude de validation de la théorie de la réponse par item"

authors = ["Sattelmayer, M.", "Hilfiker, R.", "Baer, G."]

date = "2016-01-01T00:00:00Z"

publication_types = ["2"]

publication = "In *Kinésithérapie, la Revue*."

url_source = "https://www.sciencedirect.com/science/article/pii/S1779012316300535"

projects = ["Assessment-procedures"]

math = false
highlight = false

# List format.
#   0 = Simple
#   1 = Detailed
#   2 = APA
#   3 = MLA
list_format = 3

# Optional featured image (relative to `static/img/` folder).
[header]
image = ""
caption = ""
+++
